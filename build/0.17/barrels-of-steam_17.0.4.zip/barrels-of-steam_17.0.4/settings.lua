data:extend{
  {
    type = "bool-setting",
    name = "enable-ambient-steam-barrel",
    order = "a",
    setting_type = "startup",
    default_value = false
  }
}
